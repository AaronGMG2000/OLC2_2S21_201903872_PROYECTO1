source venv/Scripts/activate
python app.py