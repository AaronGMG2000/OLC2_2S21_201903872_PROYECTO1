class Lista_Simbolo(object):

    def __init__(self, Nombre, tipo, Ambito, fila, columna):
        self.nombre = Nombre
        self.tipo = tipo
        self.ambito = Ambito
        self.fila = fila
        self.columna = columna
    